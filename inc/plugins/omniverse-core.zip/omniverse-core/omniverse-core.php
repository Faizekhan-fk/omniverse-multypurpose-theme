<?php
/*
Plugin Name: Omniverse Core
Description: Omniverse Core needed for Omniverse theme
Version: 1.1.2
Text Domain: omniverse-core
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

define( 'OMNIVERSE_CORE_PLUGIN_VERSION', '1.0.42' );

require_once 'vendor/opauth/twitteroauth/twitteroauth.php';
require_once 'inc/auth.php';
require_once 'class-post-types.php';
require_once 'post-types.php';
require_once 'inc/shortcodes.php';

<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * ------------------------------------------------------------------------------------------------
 * Products widget shortcode
 * ------------------------------------------------------------------------------------------------
 */
class OMNIVERSE_ShortcodeProductsWidget {

	function __construct() {
		add_shortcode( 'omniverse_shortcode_products_widget', array( $this, 'omniverse_shortcode_products_widget' ) );
	}

	public function add_category_order( $query_args ) {
		$ids = explode( ',', $this->ids );
		if ( ! empty( $ids[0] ) ) {
			$query_args['tax_query'][] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'id',
				'terms'    => $ids,
			);
		}
		return $query_args;
	}

	public function add_product_order( $query_args ) {
		$ids = explode( ',', $this->include_products );

		if ( ! empty( $ids[0] ) ) {
			$query_args['post__in']       = $ids;
			$query_args['orderby']        = 'post__in';
			$query_args['posts_per_page'] = -1;
		}

		return $query_args;
	}

	public function omniverse_shortcode_products_widget( $atts ) {
		global $omniverse_widget_product_img_size;
		$output = $title = $el_class = '';
		$atts   = shortcode_atts(
			array(
				'title'            => '',
				'show'             => '',
				'number'           => 3,
				'include_products' => '',
				'orderby'          => 'date',
				'order'            => 'asc',
				'ids'              => '',
				'hide_free'        => 0,
				'show_hidden'      => 0,
				'images_size'      => 'woocommerce_thumbnail',
				'el_class'         => '',
				'omniverse_css_id'  => '',
				'css'              => '',
			),
			$atts
		);
		extract( $atts );

		$omniverse_widget_product_img_size = $images_size;
		$this->ids                        = $ids;
		$this->include_products           = $include_products;


		$class = '';

		if ( ! empty( $el_class ) ) {
			$class .= $el_class;
		}

		if ( ! empty( $omniverse_css_id ) ) {
			$class .= ' wd-rs-' . $omniverse_css_id;
		}

		if ( function_exists( 'vc_shortcode_custom_css_class' ) ) {
			$class .= ' ' . vc_shortcode_custom_css_class( $css );
		}

		$output                           = '<div class="widget_products' . esc_attr( $class ) . '">';
		$type                             = 'WC_Widget_Products';

		$args = array( 'widget_id' => uniqid() );

		ob_start();

		omniverse_enqueue_inline_style( 'widget-product-list' );

		add_filter( 'woocommerce_products_widget_query_args', array( $this, 'add_category_order' ), 10 );
		add_filter( 'woocommerce_products_widget_query_args', array( $this, 'add_product_order' ), 20 );

		if ( function_exists( 'omniverse_woocommerce_installed' ) && omniverse_woocommerce_installed() ) {
			the_widget( $type, $atts, $args );
		}

		remove_filter( 'woocommerce_products_widget_query_args', array( $this, 'add_category_order' ), 10 );
		remove_filter( 'woocommerce_products_widget_query_args', array( $this, 'add_product_order' ), 20 );

		$output .= ob_get_clean();

		$output .= '</div>';

		unset( $omniverse_widget_product_img_size );

		return $output;

	}
}
$omniverse_shortcode_products_widget = new OMNIVERSE_ShortcodeProductsWidget();

function omniverse_add_shortcodes() {
	// Single product.
	add_shortcode( 'omniverse_single_product_add_to_cart', 'omniverse_shortcode_single_product_add_to_cart' );
	add_shortcode( 'omniverse_single_product_additional_info_table', 'omniverse_shortcode_single_product_additional_info_table' );
	add_shortcode( 'omniverse_single_product_brand_information', 'omniverse_shortcode_single_product_brand_information' );
	add_shortcode( 'omniverse_single_product_brands', 'omniverse_shortcode_single_product_brands' );
	add_shortcode( 'omniverse_single_product_compare_button', 'omniverse_shortcode_single_product_compare_button' );
	add_shortcode( 'omniverse_single_product_content', 'omniverse_shortcode_single_product_content' );
	add_shortcode( 'omniverse_single_product_countdown', 'omniverse_shortcode_single_product_countdown' );
	add_shortcode( 'omniverse_single_product_extra_content', 'omniverse_shortcode_single_product_extra_content' );
	add_shortcode( 'omniverse_single_product_gallery', 'omniverse_shortcode_single_product_gallery' );
	add_shortcode( 'omniverse_single_product_meta', 'omniverse_shortcode_single_product_meta' );
	add_shortcode( 'omniverse_single_product_meta_value', 'omniverse_shortcode_single_product_meta_value' );
	add_shortcode( 'omniverse_single_product_nav', 'omniverse_shortcode_single_product_nav' );
	add_shortcode( 'omniverse_single_product_price', 'omniverse_shortcode_single_product_price' );
	add_shortcode( 'omniverse_single_product_rating', 'omniverse_shortcode_single_product_rating' );
	add_shortcode( 'omniverse_single_product_reviews', 'omniverse_shortcode_single_product_reviews' );
	add_shortcode( 'omniverse_single_product_short_description', 'omniverse_shortcode_single_product_short_description' );
	add_shortcode( 'omniverse_single_product_size_guide_button', 'omniverse_shortcode_single_product_size_guide_button' );
	add_shortcode( 'omniverse_single_product_stock_progress_bar', 'omniverse_shortcode_single_product_stock_progress_bar' );
	add_shortcode( 'omniverse_single_product_tabs', 'omniverse_shortcode_single_product_tabs' );
	add_shortcode( 'omniverse_single_product_title', 'omniverse_shortcode_single_product_title' );
	add_shortcode( 'omniverse_single_product_wishlist_button', 'omniverse_shortcode_single_product_wishlist_button' );
	add_shortcode( 'omniverse_single_product_visitor_counter', 'omniverse_shortcode_single_product_visitor_counter' );
	add_shortcode( 'omniverse_single_product_linked_variations', 'omniverse_shortcode_single_product_linked_variations' );
	add_shortcode( 'omniverse_single_product_fbt_products', 'omniverse_shortcode_single_product_fbt_products' );
	add_shortcode( 'omniverse_single_product_stock_status', 'omniverse_shortcode_single_product_stock_status' );
	add_shortcode( 'omniverse_single_product_sold_counter', 'omniverse_shortcode_single_product_sold_counter' );
	add_shortcode( 'omniverse_single_product_dynamic_discounts_table', 'omniverse_shortcode_single_product_dynamic_discounts_table' );

	// Shop archive.
	add_shortcode( 'omniverse_shop_archive_active_filters', 'omniverse_shortcode_shop_archive_active_filters' );
	add_shortcode( 'omniverse_shop_archive_description', 'omniverse_shortcode_shop_archive_description' );
	add_shortcode( 'omniverse_shop_archive_extra_description', 'omniverse_shortcode_shop_category_extra_description' );
	add_shortcode( 'omniverse_shop_archive_products', 'omniverse_shortcode_shop_archive_products' );
	add_shortcode( 'omniverse_shop_archive_filters_area', 'omniverse_shortcode_shop_archive_filters_area' );
	add_shortcode( 'omniverse_shop_archive_filters_area_btn', 'omniverse_shortcode_shop_archive_filters_area_btn' );
	add_shortcode( 'omniverse_shop_archive_orderby', 'omniverse_shortcode_shop_archive_orderby' );
	add_shortcode( 'omniverse_shop_archive_orderby', 'omniverse_shortcode_shop_archive_orderby' );
	add_shortcode( 'omniverse_shop_archive_per_page', 'omniverse_shortcode_shop_archive_per_page' );
	add_shortcode( 'omniverse_shop_archive_result_count', 'omniverse_shortcode_shop_archive_result_count' );
	add_shortcode( 'omniverse_sidebar', 'omniverse_shortcode_sidebar' );
	add_shortcode( 'omniverse_shop_archive_view', 'omniverse_shortcode_shop_archive_view' );
	add_shortcode( 'omniverse_shop_archive_woocommerce_title', 'omniverse_shortcode_shop_archive_woocommerce_title' );

	// Cart.
	add_shortcode( 'omniverse_cart_table', 'omniverse_shortcode_cart_table' );
	add_shortcode( 'omniverse_cart_totals', 'omniverse_shortcode_cart_totals' );

	// Checkout.
	add_shortcode( 'omniverse_checkout_billing_details_form', 'omniverse_shortcode_checkout_billing_details_form' );
	add_shortcode( 'omniverse_checkout_coupon_form', 'omniverse_shortcode_checkout_coupon_form' );
	add_shortcode( 'omniverse_checkout_login_form', 'omniverse_shortcode_checkout_login_form' );
	add_shortcode( 'omniverse_checkout_order_review', 'omniverse_shortcode_checkout_order_review' );
	add_shortcode( 'omniverse_checkout_payment_methods', 'omniverse_shortcode_checkout_payment_methods' );
	add_shortcode( 'omniverse_checkout_shipping_details_form', 'omniverse_shortcode_checkout_shipping_details_form' );

	// WooCommerce.
	add_shortcode( 'omniverse_woocommerce_breadcrumb', 'omniverse_shortcode_woocommerce_breadcrumb' );
	add_shortcode( 'omniverse_woocommerce_checkout_steps', 'omniverse_shortcode_woocommerce_checkout_steps' );
	add_shortcode( 'omniverse_woocommerce_hook', 'omniverse_shortcode_woocommerce_hook' );
	add_shortcode( 'omniverse_woocommerce_notices', 'omniverse_shortcode_woocommerce_notices' );
	add_shortcode( 'omniverse_page_title', 'omniverse_shortcode_page_title' );
	add_shortcode( 'omniverse_shipping_progress_bar', 'omniverse_shortcode_shipping_progress_bar' );

	add_shortcode( 'html_block', 'omniverse_html_block_shortcode' );
	add_shortcode( 'social_buttons', 'omniverse_shortcode_social' );
	add_shortcode( 'omniverse_info_box', 'omniverse_shortcode_info_box' );
	add_shortcode( 'omniverse_info_box_carousel', 'omniverse_shortcode_info_box_carousel' );
	add_shortcode( 'omniverse_button', 'omniverse_shortcode_button' );
	add_shortcode( 'author_area', 'omniverse_shortcode_author_area' );
	add_shortcode( 'promo_banner', 'omniverse_shortcode_promo_banner' );
	add_shortcode( 'banners_carousel', 'omniverse_shortcode_banners_carousel' );
	add_shortcode( 'omniverse_instagram', 'omniverse_shortcode_instagram' );
	add_shortcode( 'user_panel', 'omniverse_shortcode_user_panel' );
	add_shortcode( 'omniverse_size_guide', 'omniverse_size_guide_shortcode' );
	add_shortcode( 'omniverse_gallery', 'omniverse_images_gallery_shortcode' );
	add_shortcode( 'omniverse_blog', 'omniverse_shortcode_blog' );
	if ( class_exists( 'XTS\Modules\Compare\Ui' ) ) {
		add_shortcode( 'omniverse_compare', array( XTS\Modules\Compare\Ui::get_instance(), 'compare_page' ) );
	}
	if ( class_exists( 'XTS\WC_Wishlist\Ui' ) ) {
		add_shortcode( 'omniverse_wishlist', array( XTS\WC_Wishlist\Ui::get_instance(), 'wishlist_page' ) );
	}

	if ( function_exists( 'omniverse_get_current_page_builder' ) && 'wpb' === omniverse_get_current_page_builder() ) {
		add_shortcode( 'omniverse_3d_view', 'omniverse_shortcode_3d_view' );
		add_shortcode( 'omniverse_ajax_search', 'omniverse_ajax_search' );
		add_shortcode( 'omniverse_countdown_timer', 'omniverse_shortcode_countdown_timer' );
		add_shortcode( 'omniverse_counter', 'omniverse_shortcode_animated_counter' );
		add_shortcode( 'extra_menu', 'omniverse_shortcode_extra_menu' );
		add_shortcode( 'extra_menu_list', 'omniverse_shortcode_extra_menu_list' );
		add_shortcode( 'omniverse_google_map', 'omniverse_shortcode_google_map' );
		add_shortcode( 'omniverse_image_hotspot', 'omniverse_image_hotspot_shortcode' );
		add_shortcode( 'omniverse_hotspot', 'omniverse_hotspot_shortcode' );
		add_shortcode( 'omniverse_list', 'omniverse_list_shortcode' );
		add_shortcode( 'omniverse_mega_menu', 'omniverse_shortcode_mega_menu' );
		add_shortcode( 'omniverse_menu_price', 'omniverse_shortcode_menu_price' );
		add_shortcode( 'omniverse_popup', 'omniverse_shortcode_popup' );
		add_shortcode( 'omniverse_portfolio', 'omniverse_shortcode_portfolio' );
		add_shortcode( 'pricing_tables', 'omniverse_shortcode_pricing_tables' );
		add_shortcode( 'pricing_plan', 'omniverse_shortcode_pricing_plan' );
		add_shortcode( 'omniverse_responsive_text_block', 'omniverse_shortcode_responsive_text_block' );
		add_shortcode( 'omniverse_text_block', 'omniverse_shortcode_text_block' );
		add_shortcode( 'omniverse_marquee', 'omniverse_shortcode_marquee' );
		add_shortcode( 'omniverse_nested_carousel', 'omniverse_shortcode_nested_carousel' );
		add_shortcode( 'omniverse_nested_carousel_item', 'omniverse_shortcode_nested_carousel_item' );
		add_shortcode( 'omniverse_image', 'omniverse_shortcode_image' );
		add_shortcode( 'omniverse_mailchimp', 'omniverse_shortcode_mailchimp' );
		add_shortcode( 'omniverse_row_divider', 'omniverse_row_divider' );
		add_shortcode( 'omniverse_slider', 'omniverse_shortcode_slider' );
		add_shortcode( 'team_member', 'omniverse_shortcode_team_member' );
		add_shortcode( 'testimonials', 'omniverse_shortcode_testimonials' );
		add_shortcode( 'testimonial', 'omniverse_shortcode_testimonial' );
		add_shortcode( 'omniverse_timeline', 'omniverse_timeline_shortcode' );
		add_shortcode( 'omniverse_timeline_item', 'omniverse_timeline_item_shortcode' );
		add_shortcode( 'omniverse_timeline_breakpoint', 'omniverse_timeline_breakpoint_shortcode' );
		add_shortcode( 'omniverse_title', 'omniverse_shortcode_title' );
		add_shortcode( 'omniverse_twitter', 'omniverse_twitter' );
		add_shortcode( 'omniverse_tabs', 'omniverse_shortcode_tabs' );
		add_shortcode( 'omniverse_tab', 'omniverse_shortcode_tab' );
		add_shortcode( 'omniverse_accordion', 'omniverse_shortcode_accordion' );
		add_shortcode( 'omniverse_accordion_item', 'omniverse_shortcode_accordion_item' );
		add_shortcode( 'omniverse_off_canvas_btn', 'omniverse_shortcode_off_canvas_btn' );
		add_shortcode( 'omniverse_open_street_map', 'omniverse_shortcode_open_street_map' );
		add_shortcode( 'omniverse_table', 'omniverse_shortcode_table' );
		add_shortcode( 'omniverse_table_row', 'omniverse_shortcode_table_row' );
		add_shortcode( 'omniverse_video', 'omniverse_shortcode_video' );

		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
			add_shortcode( 'products_tabs', 'omniverse_shortcode_products_tabs' );
			add_shortcode( 'products_tab', 'omniverse_shortcode_products_tab' );
			add_shortcode( 'omniverse_brands', 'omniverse_shortcode_brands' );
			add_shortcode( 'omniverse_categories', 'omniverse_shortcode_categories' );
			add_shortcode( 'omniverse_product_filters', 'omniverse_product_filters_shortcode' );
			add_shortcode( 'omniverse_filter_categories', 'omniverse_filters_categories_shortcode' );
			add_shortcode( 'omniverse_filters_attribute', 'omniverse_filters_attribute_shortcode' );
			add_shortcode( 'omniverse_filters_orderby', 'omniverse_orderby_filter_template' );
			add_shortcode( 'omniverse_filters_price_slider', 'omniverse_filters_price_slider_shortcode' );
			add_shortcode( 'omniverse_stock_status', 'omniverse_stock_status_shortcode' );
			add_shortcode( 'omniverse_products', 'omniverse_shortcode_products' );
		}

		if ( function_exists( 'vc_add_shortcode_param' ) ) {
			vc_add_shortcode_param( 'omniverse_datepicker', 'omniverse_get_datepicker_param' );
			vc_add_shortcode_param( 'omniverse_button_set', 'omniverse_get_button_set_param' );
			vc_add_shortcode_param( 'omniverse_colorpicker', 'omniverse_get_colorpicker_param' );
			vc_add_shortcode_param( 'omniverse_css_id', 'omniverse_get_css_id_param' );
			vc_add_shortcode_param( 'omniverse_dropdown', 'omniverse_get_dropdown_param' );
			vc_add_shortcode_param( 'omniverse_empty_space', 'omniverse_get_empty_space_param' );
			vc_add_shortcode_param( 'omniverse_gradient', 'omniverse_add_gradient_type' );
			vc_add_shortcode_param( 'omniverse_image_hotspot', 'omniverse_image_hotspot' );
			vc_add_shortcode_param( 'omniverse_image_select', 'omniverse_add_image_select_type' );
			vc_add_shortcode_param( 'omniverse_responsive_size', 'omniverse_get_responsive_size_param' );
			vc_add_shortcode_param( 'omniverse_responsive_spacing', 'omniverse_get_responsive_spacing_param' );
			vc_add_shortcode_param( 'omniverse_slider', 'omniverse_get_slider_param' );
			vc_add_shortcode_param( 'omniverse_switch', 'omniverse_get_switch_param' );
			vc_add_shortcode_param( 'omniverse_title_divider', 'omniverse_get_title_divider_param' );

			vc_add_shortcode_param( 'wd_slider', 'omniverse_get_slider_responsive_param' );
			vc_add_shortcode_param( 'wd_number', 'omniverse_get_number_param' );
			vc_add_shortcode_param( 'wd_colorpicker', 'omniverse_get_wd_colorpicker_param' );
			vc_add_shortcode_param( 'wd_box_shadow', 'omniverse_get_box_shadow_param' );
			vc_add_shortcode_param( 'wd_select', 'omniverse_get_select_param' );
			vc_add_shortcode_param( 'wd_notice', 'omniverse_get_notice_param' );
			vc_add_shortcode_param( 'wd_dimensions', 'omniverse_get_dimensions_responsive_param' );
			vc_add_shortcode_param( 'wd_fonts', 'omniverse_get_fonts_param' );
			vc_add_shortcode_param( 'wd_upload', 'omniverse_get_upload_param' );
		}
	}

	if ( function_exists( 'omniverse_get_opt' ) && omniverse_get_opt( 'single_post_justified_gallery' ) ) {
		remove_shortcode( 'gallery' );
		add_shortcode( 'gallery', 'omniverse_gallery_shortcode' );
	}
}
add_action( 'init', 'omniverse_add_shortcodes' );

/**
 * ------------------------------------------------------------------------------------------------
 * Add metaboxes to the product
 * ------------------------------------------------------------------------------------------------
 */

if ( ! function_exists( 'omniverse_product_360_view_meta' ) ) {
	function omniverse_product_360_view_meta() {
		if ( ! function_exists( 'omniverse_get_opt' ) ) {
			return;
		}

		add_meta_box( 'woocommerce-product-360-images', esc_html__( 'Product 360 View Gallery (optional)', 'omniverse' ), 'omniverse_360_metabox_output', 'product', 'side', 'low' );
	}
	add_action( 'add_meta_boxes', 'omniverse_product_360_view_meta', 50 );
}

/**
 * ------------------------------------------------------------------------------------------------
 * Add metaboxes
 * ------------------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'omniverse_sguide_add_metaboxes' ) ) {
	function omniverse_sguide_add_metaboxes() {
		if ( ! function_exists( 'omniverse_get_opt' ) || ! omniverse_get_opt( 'size_guides' ) ) {
			return;
		}

		// Add table metaboxes to size guide
		add_meta_box( 'omniverse_sguide_metaboxes', esc_html__( 'Create/modify size guide table', 'omniverse' ), 'omniverse_sguide_metaboxes', 'omniverse_size_guide', 'normal', 'default' );
		// Add metaboxes to product
		add_meta_box( 'omniverse_sguide_dropdown_template', esc_html__( 'Choose size guide', 'omniverse' ), 'omniverse_sguide_dropdown_template', 'product', 'side' );
		// Add category metaboxes to size guide
		add_meta_box( 'omniverse_sguide_category_template', esc_html__( 'Choose product categories', 'omniverse' ), 'omniverse_sguide_category_template', 'omniverse_size_guide', 'side' );
		// Add hide table checkbox to size guide
		add_meta_box( 'omniverse_sguide_hide_table_template', esc_html__( 'Hide size guide table', 'omniverse' ), 'omniverse_sguide_hide_table_template', 'omniverse_size_guide', 'side' );
	}
	add_action( 'add_meta_boxes', 'omniverse_sguide_add_metaboxes' );
}

if ( ! function_exists( 'omniverse_widgets_init' ) ) {
	function omniverse_widgets_init() {
		if ( ! is_blog_installed() || ! class_exists( 'OMNIVERSE_WP_Nav_Menu_Widget' ) ) {
			return;
		}

		register_widget( 'OMNIVERSE_WP_Nav_Menu_Widget' );
		register_widget( 'OMNIVERSE_Banner_Widget' );
		register_widget( 'OMNIVERSE_Author_Area_Widget' );
		register_widget( 'OMNIVERSE_Instagram_Widget' );
		register_widget( 'OMNIVERSE_Static_Block_Widget' );
		register_widget( 'OMNIVERSE_Recent_Posts' );
		register_widget( 'OMNIVERSE_Twitter' );
		register_widget( 'OMNIVERSE_Widget_Mailchimp' );

		if ( omniverse_woocommerce_installed() ) {
			register_widget( 'OMNIVERSE_User_Panel_Widget' );
			register_widget( 'OMNIVERSE_Widget_Layered_Nav' );
			register_widget( 'OMNIVERSE_Widget_Sorting' );
			register_widget( 'OMNIVERSE_Widget_Price_Filter' );
			register_widget( 'OMNIVERSE_Widget_Search' );
			register_widget( 'OMNIVERSE_Stock_Status' );
		}

	}

	add_action( 'widgets_init', 'omniverse_widgets_init' );
}


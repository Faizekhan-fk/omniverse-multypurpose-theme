<?php
/**
 * Post types file.
 *
 * @package Woodmart
 */

namespace WOODCORE;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}

/**
 * Post types class.
 */
class Post_Types {
	/**
	 * Instance.
	 *
	 * @var null
	 */
	public static $instance = null;

	/**
	 * Instance.
	 *
	 * @return Post_Types|null
	 */
	public static function get_instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_layout' ), 1 );
		add_action( 'init', array( $this, 'linked_variations' ), 1 );
		add_action( 'init', array( $this, 'bought_together' ), 1 );
		add_action( 'init', array( $this, 'register_discounts' ), 1 );
	}

	/**
	 * Register layout post type.
	 */
	public function register_layout() {
		register_post_type(
			'omniverse_layout',
			array(
				'label'              => esc_html__( 'Layouts', 'omniverse' ),
				'labels'             => array(
					'name'          => esc_html__( 'Layouts', 'omniverse' ),
					'singular_name' => esc_html__( 'Layout', 'omniverse' ),
					'menu_name'     => esc_html__( 'Layouts', 'omniverse' ),
					'add_new'       => esc_html__( 'Add New', 'omniverse' ),
					'add_new_item'  => esc_html__( 'Add New', 'omniverse' ),
				),
				'supports'           => array( 'title', 'editor' ),
				'hierarchical'       => false,
				'public'             => true,
				'menu_position'      => 32,
				'menu_icon'          => 'dashicons-format-gallery',
				'publicly_queryable' => is_user_logged_in(),
				'show_in_rest'       => true,
				'capability_type'    => 'page',
			)
		);
	}

	/**
	 * Register layout post type.
	 */
	public function linked_variations() {
		if ( ! function_exists( 'omniverse_get_opt' ) || ! omniverse_get_opt( 'linked_variations', 1 ) ) {
			return;
		}

		register_post_type(
			'omniverse_woo_lv',
			array(
				'label'              => esc_html__( 'Linked Variations', 'omniverse' ),
				'labels'             => array(
					'name'          => esc_html__( 'Linked Variations', 'omniverse' ),
					'singular_name' => esc_html__( 'Linked Variations', 'omniverse' ),
					'menu_name'     => esc_html__( 'Linked Variations', 'omniverse' ),
					'add_new'       => esc_html__( 'Add New', 'omniverse' ),
					'add_new_item'  => esc_html__( 'Add New', 'omniverse' ),
				),
				'supports'           => array( 'title' ),
				'hierarchical'       => false,
				'public'             => true,
				'show_in_menu'       => 'edit.php?post_type=product',
				'publicly_queryable' => false,
				'show_in_rest'       => true,
			)
		);
	}

	/**
	 * Register frequently bought together post type.
	 */
	public function bought_together() {
		if ( ! function_exists( 'omniverse_get_opt' ) || ! omniverse_get_opt( 'bought_together_enabled', 1 ) ) {
			return;
		}

		register_post_type(
			'omniverse_woo_fbt',
			array(
				'label'              => esc_html__( 'Frequently Bought Together', 'omniverse' ),
				'labels'             => array(
					'name'          => esc_html__( 'Frequently Bought Together', 'omniverse' ),
					'singular_name' => esc_html__( 'Frequently Bought Together', 'omniverse' ),
					'menu_name'     => esc_html__( 'Frequently Bought Together', 'omniverse' ),
					'add_new'       => esc_html__( 'Add New', 'omniverse' ),
					'add_new_item'  => esc_html__( 'Add New', 'omniverse' ),
				),
				'supports'           => array( 'title' ),
				'hierarchical'       => false,
				'public'             => true,
				'show_in_menu'       => 'edit.php?post_type=product',
				'publicly_queryable' => false,
				'show_in_rest'       => true,
			)
		);
	}

	/**
	 * Register Dynamic Pricing & Discounts post type.
	 */
	public function register_discounts() {
		if ( ! function_exists( 'omniverse_get_opt' ) || ! omniverse_get_opt( 'discounts_enabled', 0 ) ) {
			return;
		}

		register_post_type(
			'wd_woo_discounts',
			array(
				'label'              => esc_html__( 'Dynamic Discounts', 'omniverse' ),
				'labels'             => array(
					'name'          => esc_html__( 'Dynamic Discounts', 'omniverse' ),
					'singular_name' => esc_html__( 'Dynamic Discount', 'omniverse' ),
					'menu_name'     => esc_html__( 'Dynamic Discounts', 'omniverse' ),
					'add_new'       => esc_html__( 'Add New', 'omniverse' ),
					'add_new_item'  => esc_html__( 'Add New', 'omniverse' ),
				),
				'supports'           => array( 'title' ),
				'hierarchical'       => false,
				'public'             => true,
				'show_in_menu'       => 'edit.php?post_type=product',
				'publicly_queryable' => false,
				'show_in_rest'       => true,
			)
		);
	}
}

Post_Types::get_instance();
